document.addEventListener("DOMContentLoaded", () => {
  const petals = document.getElementById("petals");
  const modal = document.getElementById("rsvp-modal");
  const form = document.getElementById("wishes-form");
  const thanks = document.getElementById("thanks");
  const nameInput = form.querySelector("input[name='name']");

  for (let index = 0; index < 14; index += 1) {
    const petal = document.createElement("i");
    petal.style.left = `${(index * 17 + 4) % 100}%`;
    petal.style.animationDelay = `${(index % 7) * -1.3}s`;
    petal.style.animationDuration = `${8 + (index % 5) * 1.8}s`;
    petals.appendChild(petal);
  }

  function openModal() {
    modal.hidden = false;
    document.body.style.overflow = "hidden";
    window.setTimeout(() => nameInput.focus(), 50);
  }

  function closeModal() {
    modal.hidden = true;
    document.body.style.overflow = "";
  }

  document.querySelectorAll(".open-rsvp").forEach((button) => button.addEventListener("click", openModal));
  document.querySelector(".modal-close").addEventListener("click", closeModal);
  document.querySelector(".close-thanks").addEventListener("click", closeModal);
  modal.addEventListener("mousedown", (event) => { if (event.target === modal) closeModal(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeModal(); });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    localStorage.setItem("rajashree-shama-wish", JSON.stringify(data));
    form.hidden = true;
    thanks.hidden = false;
  });

  async function shareInvitation() {
    const details = {
      title: "Rajashree & Shama — Wedding Invitation",
      text: "Join us as Rajashree and Shama begin their forever.",
      url: window.location.href,
    };
    try {
      if (navigator.share) await navigator.share(details);
      else {
        await navigator.clipboard.writeText(window.location.href);
        alert("Invitation link copied!");
      }
    } catch (error) {
      if (error.name !== "AbortError") alert("Please copy the page link from your browser.");
    }
  }

  document.querySelectorAll(".share-button").forEach((button) => button.addEventListener("click", shareInvitation));
});
